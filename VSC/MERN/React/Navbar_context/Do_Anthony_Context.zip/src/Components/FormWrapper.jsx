import React, {useContext} from "react"

import NameForm from "./NameForm"


const FormWrapper = props => 
{
    return (
        <div>
            <NameForm/>        
        </div>
        )
}

export default FormWrapper