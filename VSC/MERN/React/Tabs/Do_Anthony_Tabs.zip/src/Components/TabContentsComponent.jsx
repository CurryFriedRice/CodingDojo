import React, {useState} from 'react'


const TabContent = props => 
{
    return (
        <div className="content">{props.TabContent}</div>
    )
}
export default TabContent;