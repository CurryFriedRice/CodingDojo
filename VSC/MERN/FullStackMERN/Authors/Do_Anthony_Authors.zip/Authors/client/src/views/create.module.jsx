import react, {useState}  from 'react'
import axios from 'axios'
//IMPORTING CSS FROM MODULE
// import style from "./main.module.css"

import Form from '../components/Form' 

import {Link, useHistory} from 'react-router-dom'

export default (props) =>{
    const [name, setName] = useState()
    const history = useHistory();
    // useEffect(() => {
    //     axios.get("http://localhost:8000/api/notes")
    //     .then(res => {
    //         console.log(res.data)   //Logs the data to see if we're even getting it
    //         setNotes(res.data)
    //     })
    //     .catch(err => console.log(err))
    // },[])

    const addItem = (e, authorName) =>
    {
        e.preventDefault();
        console.log("adding Item", authorName)
        axios.post("http://localhost:8000/api/authors", {name: authorName})
            .then(res => {
                console.log(res.data)
                history.push(`/`)
            })
            .catch(err => console.log(err))
    } 
  
    return (
        <div>
            <Link to="/authors">Home</Link>
            <h3>Add new Author</h3>
            <Form onSubmitHandler={addItem} name={name} setName={setName}/>
        </div>
    )
}
