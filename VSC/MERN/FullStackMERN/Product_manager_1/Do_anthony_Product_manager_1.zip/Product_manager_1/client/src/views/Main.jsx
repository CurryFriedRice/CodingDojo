import React from "react";
import ProductForm from "../components/ProductForm"

export default () => 
{

    return (
        <>
        {/* <p>Message from the backend: {message}</p>
        <div>{JSON.stringify(message)}</div> */}
        {/* <PersonForm/> */}
        <ProductForm></ProductForm>
        </>
    )
}

