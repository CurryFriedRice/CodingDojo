

namespace dojo_survey.Models
{
    public class SurveyResponse
    {
        public string Name { get; set; }
        public string Place {get;set;}
        public string Activity{get;set;}
        public string Comment {get;set;}
    }
}