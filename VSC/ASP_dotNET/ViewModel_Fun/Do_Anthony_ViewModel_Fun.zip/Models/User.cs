using System;

namespace ViewModel_Fun.Models
{
    public class User
    {   
        public string firstName{get;set;}
        public string lastName{get;set;}
    }
}
