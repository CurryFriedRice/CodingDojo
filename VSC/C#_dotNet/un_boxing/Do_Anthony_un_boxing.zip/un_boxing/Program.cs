﻿using System;
using System.Collections.Generic;

namespace un_boxing
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            List<object> items = Boxer.boxed();
            Unboxer.unbox(items);
        }

        
    
    }

    
}
