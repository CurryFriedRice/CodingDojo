using System;

namespace phone_assignment
{
    public interface IRingable
    {
        string Ring();
        string Unlock();
    }
    
}
