using System;

namespace hungry_ninja
{
    public class Food
    {
        public string Name;
        public int Calories;

        public bool IsSweet;
        public bool IsSpicy;

        public Food(string Name, int Calories, bool Sweet, bool Spicy)
        {
            this.Name = Name;
            this.Calories = Calories;
            this.IsSpicy = Spicy;
            this.IsSweet = Sweet;
        }
    }
}