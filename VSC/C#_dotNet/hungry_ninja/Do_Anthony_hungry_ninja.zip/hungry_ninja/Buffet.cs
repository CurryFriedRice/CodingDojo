using System;
using System.Collections.Generic;

namespace hungry_ninja
{
    public class Buffet
    {
        public List<Food> Menu;
        
        public Buffet()
        {
            Menu = new List<Food>()
            {
                new Food("Borger", 1000, false,false),
                new Food("Pasta", 1250, false,false)
            };
        }

        public Food OrderFood(int index)
        {
            return Menu[index];
        }
    }
}