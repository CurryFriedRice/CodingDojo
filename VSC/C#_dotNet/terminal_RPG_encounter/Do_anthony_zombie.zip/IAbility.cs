using System;

namespace terminal_RPG_encounter
{
    public interface IAbility
    {
        int Ability(Unit Target);
        
    }
}
