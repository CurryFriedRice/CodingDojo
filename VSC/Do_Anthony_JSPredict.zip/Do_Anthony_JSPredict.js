//Predict 1: No input Data
//Output: I was Born in 1980

//Predict 2: birthYearInput = 1980
//Output: I was born in 1980

//More outputs means I changed the format 
//Predict 3: var num1 = 10 and var num2 = 20
//=====Output Below=====
//Summing Numbers!
//num1 is: 10
//num2 is: 20
//30
